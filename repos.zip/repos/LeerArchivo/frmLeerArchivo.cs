﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using pjBiblioteca_Banco;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LeerArchivo
{
    public partial class frmLeerArchivo : frmBanco_UI
    {
        private FileStream entrada; // mantieene la conexion a un archivo
        private StreamReader archivoReader; // lee los datos de un archivo de textro


        public frmLeerArchivo()
        {
            InitializeComponent();
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            //crea un cuadro de dialogo que permite al usuario abrir el archivo
            OpenFileDialog selectorArchivo = new OpenFileDialog();
            DialogResult resultado = selectorArchivo.ShowDialog();
            string nombreArchivo; // nombre del archivo que contiene los datos

            // sale del manejador de eventos si el usuarffio hace click en Cancelar 
            if (resultado == DialogResult.Cancel)
            
                return;
                nombreArchivo = selectorArchivo.FileName; // obtiene el nombre del archivo especificado
                LimpiaControlesTextBox();

                //muestra error si el usuario especifica un archivo invalido
                if (nombreArchivo == "" || nombreArchivo == null)
                {
                    MessageBox.Show("Nombre de archivo invalido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    try
                    {
                        // crea objeto FileStream para obtener acceso de lectura al archivo
                        entrada = new FileStream(nombreArchivo, FileMode.Open, FileAccess.Read);
                        //establece el archivo del que se van a leer los datos
                        archivoReader = new StreamReader(entrada);

                        btnAbrir.Enabled = false; // deshabilita el boton abrir archivo
                        btnSiguiente.Enabled = true; ///  habilita el btn siguiente
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("Error al leer archivo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            try
            {
                //obtiene eel siguiente registro disponible en el archivo
                string registroEntrada = archivoReader.ReadLine();
                string[] camposEntrada; // almacena piezas individuales de datos

                if (registroEntrada != null)
                {
                    camposEntrada = registroEntrada.Split(',');

                    Registro registro = new Registro(Convert.ToInt32(camposEntrada[0]),
                    camposEntrada[1], camposEntrada[2], Convert.ToDecimal(camposEntrada[3]));

                    EstablecerValoresControlesTextBox(camposEntrada);
                }
                else
                {
                    archivoReader.Close();
                    //cierra StreamReader
                    entrada.Close();// ccierra FileStream si no hay registro en el archivo
                    btnAbrir.Enabled = true; // habilita el boton abrir archivo
                    btnSiguiente.Enabled = false; // deshabilita el boton siguiente registro

                    LimpiaControlesTextBox();

                    //notifica al usuario si no hay registro
                    MessageBox.Show("No hay registro en el archivo", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Error al leer el archivo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
