﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using pjBiblioteca_Banco;

namespace Crear_Archivo
{
    public partial class frmCrear_Archivo : frmBanco_UI
    {
        private StreamWriter ArchivoWriter; //escribe datos en el archivo de texto
        private FileStream salida; //mantiene la conexion con el archivo

        public frmCrear_Archivo()
        {
            InitializeComponent();
        }
        //manejador de eventos para el boton guardar
        private void btnGuarda_Click(object sender, EventArgs e)
        {
            //crea un cuadro de dialogo que permita al usuario guardar el archivo
            //SaveFileDialog y el DialogResult van de la mano o juntas
            SaveFileDialog selectorArchivo = new SaveFileDialog();
            DialogResult resultado = selectorArchivo.ShowDialog();
            string nombreArchivo; //nombre del archivo en el que se van a guardar los datos

            selectorArchivo.CheckFileExists = false;//permite al usuario crear el archivo

            //sale del manejador de eventos si el usuario have clic en "cancelar"

            if (resultado == DialogResult.Cancel)
                return;

            nombreArchivo = selectorArchivo.FileName;//obtiene el nombre del archivo especificado

            //muestra error si el ususario especifico un archivo invalido

            if(nombreArchivo == "" || nombreArchivo == null)
            {
                MessageBox.Show("caracter invalido", "error",
                    MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    //guardar el archivo mediante el objeto FileStream, si el usuario especifico un archivo

                    salida = new FileStream(nombreArchivo, FileMode.OpenOrCreate, FileAccess.Write);
                    //estable el archivo para escribir los datos
                    ArchivoWriter = new StreamWriter(salida);

                    //deshabilitar el boton guaradar y habiliar el boton entrar
                    btnEntrar.Enabled = false;
                    btnEntrar.Enabled = true;
                }
                catch (IOException)
                {
                    // notifica al usuario si el archivo no existe
                    MessageBox.Show("error al abrir el archivo", "Error"
                        , MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
        }

        //manejador de eventos para el boton Entrar
        private void btnEntrar_Click(object sender, EventArgs e)
        {

            // almacena el arreglo de string de valores de los controles Textbox
            string[] valores = ObtenerValoresControlesTextBox();

            //Registro que contiene los valores de los controles TextBox
            Registro registros = new Registro();

            //determina si el campo del control TextBox esta vacio
            if (valores[(int)IndicesTextBox.CUENTA] != "")
            {
                //almacenar los valores de los controles TextBox en Registro

                //obtiene el valor del numero de cuenta del control TextBox
                int numeroCuenta = int.Parse(valores[(int)IndicesTextBox.CUENTA]);

                try
                {
                    //determina si el numero es valido
                    if (numeroCuenta > 0)
                    {
                        //Almacena los campos TextBox en Registro 
                        registros.Cuenta = numeroCuenta;
                        registros.Nombre = valores[(int)IndicesTextBox.NOMBRE];
                        registros.Apellido = valores[(int)IndicesTextBox.APELLIDO];
                        registros.Saldo = decimal.Parse(valores[(int)IndicesTextBox.SALDO]);

                        //escribe al archivo el registro de los campos separeadps por comas
                        ArchivoWriter.WriteLine(registros.Cuenta + "," + registros.Nombre + "," + registros.Apellido + "," + registros.Saldo);
                    }
                    else
                    {
                        //notificar al usuario si el numero de cuenta es invalido
                        MessageBox.Show("numero de cuenta invalido", "ERROR",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (IOException)
                {
                    MessageBox.Show("Error al escribir en archivo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                //notifica al usuario si ocurre un error relacionado con el formato
                catch (FormatException)
                {
                    MessageBox.Show("Formato invalido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            LimpiaControlesTextBox(); // limpia los valores de los controles de texBox
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            //determina su ek archivo excise o no
            if (salida != null)
            {
                try
                {
                    ArchivoWriter.Close();
                    salida.Close();
                }
                //notifica al usuario del error al cerrar archivo
                catch (IOException)
                {
                    MessageBox.Show("No se puede cerrar el archivo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            Application.Exit();
        }
    }
}
