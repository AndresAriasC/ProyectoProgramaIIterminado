﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pjBiblioteca_Banco
{
    public partial class frmBanco_UI : Form
    {
        protected int CuentaTextBox = 4; // numero de control TextBox en el formulario

        //las constantes de la enumeracion especifica los indices de los controles TextBox

        public enum IndicesTextBox
        {
            CUENTA,
            NOMBRE,
            APELLIDO,
            SALDO
        }
        public frmBanco_UI()
        {
            InitializeComponent();
        }
        //limpiar

        public void LimpiaControlesTextBox()
        {
            //itera a traves de cada control en el formulario

            for(int i = 0; i < CuentaTextBox; i++)
            {
                Control miCOntrol = Controls[i]; //obtiene el control

                //determina si el control es un TextBox
                if(miCOntrol is TextBox)
                {
                    //limpiar la propiedad Text (la establece a una cadena vacia)

                    miCOntrol.Text = "";
                    
                }
            }
        }

        //establece los valores de los controles TextBox con el arreglo string valores

        public void EstablecerValoresControlesTextBox(string[] valores)
        {
            //determina si el arreglo string tiene la longitud correcta
            if(valores.Length != CuentaTextBox)
            {
                //lanza excepcion si no tiene longitud correcta
                throw new ArgumentException("debe haber" +
                    (CuentaTextBox + 1) + "objetos string en el arreglo");
            }
            else
            {
                //establece valores al arreglo con los valores de los controles textBox
                txtCuenta.Text = valores[(int)IndicesTextBox.CUENTA];
                txtNombre.Text = valores[(int)IndicesTextBox.NOMBRE];
                txtApellido.Text= valores[(int)IndicesTextBox.APELLIDO];
                txtSaldo.Text = valores[(int)IndicesTextBox.SALDO];
            }
        }

        //devuelve los valores de los controles TextBox como un Arreglo string
        public string[] ObtenerValoresControlesTextBox()
        {
            string[] valores = new string[CuentaTextBox];

            //copiamos los campos de los controles de los TextBox al Arreglo string
            valores[(int)IndicesTextBox.CUENTA] = txtCuenta.Text;
            valores[(int)IndicesTextBox.NOMBRE] = txtNombre.Text;
            valores[(int)IndicesTextBox.APELLIDO] = txtApellido.Text;
            valores[(int)IndicesTextBox.SALDO] = txtSaldo.Text;

            return valores;
        }
    }
}
